# Exercise: Reading Tests

In this exercise, you will deduce what some given test specs are testing for.

## Set Up

Clone the exercise from the [starter].

## Instructions

Take a look at the __test/specs.js__ file provided to you. Deduce what the file
is testing.

[starter]: https://github.com/appacademy/practice-for-week-04-reading-tests-exercise